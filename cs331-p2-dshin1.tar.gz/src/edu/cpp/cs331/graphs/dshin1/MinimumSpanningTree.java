package edu.cpp.cs331.graphs.dshin1;

public interface MinimumSpanningTree 
{
	Graph genMST(Graph g);
}
